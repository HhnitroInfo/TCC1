function insereV() {
     

$.get("../Cadastros/BuscaProduto.php?codP=" + codP, function (data, status) {
     if (status == 'success') {
         alert("inserão realizadacom sucesso");
         

     } else {
         alert("Erro na insersão de dados");
     }
 });
}


 $(document).ready(function () {
  
     



 });