$(document).ready(function () {

    $("#nomePH").hide();
    $("#quantestH").hide();
    $("#marcaH").hide();
    $("#grupoH").hide();
    $("#VCH").hide();
    $("#LU").hide();
    $("#DescH").hide();
    $("#Vven").hide();
    $("#OBSH").hide();    
    var idadeN = 0;
    







    function validanomeP() {
        var nome = $("#nome").val().trim();
        if (nome == "") {
            $("#nome").addClass("error");
            $("#nomePH").addClass("texterror");

            $("#nomePH").show();
            return false;
        } else {
            $("#nome").removeClass("error");
            $("#nomePH").removeClass("texterror");
            $("#nomePH").hide();
            return true;
        }
    }




    function validquantest() {
        var quntest = $("#quantest").val().trim();
        if (quantest == "" ) {
            $("#quantest").addClass("error");
            $("#quantestH").show();

            return false;
        } else {
            $("#quantest").removeClass("error");
            $("#quantestH").hide();
            return true;
        }
    }
    function validamaarca() {
        var marca = $("#marca").val().trim();
        if (marca == "") {
            $("#marca").addClass("error");
            $("#marcaH").show();

            return false;

        }  else {
            $("marca").removeClass("error");
            $("#marcaH").hide();
            return true;
        }


    }

    function validagrupo() {
        var marca = $("#marca").val().trim();
        if (marca == "") {
            $("#marca").addClass("error");
            $("#marcaH").show();          
            return false;

        }  else {
                $("#marca").removeClass("error");
                $("#marcaH").hide();
                return true;
            }


        }
    


    function validagrupo() {
        var gr = $("#grupo").val().trim();

        if (gr == "") {
            $("#grupo").addClass("error");
            $("#grupoH").show();
            return false;

        } else {
            $("#grupo").removeClass("error");
            $("#grupoH").hide();
           
            return true;
        }

    }

    function validaVC() {
        var vc = $("#Vcusto").val().trim();
        if (vc == 0 || vc == "") {
            $("#Vcusto").addClass("error");
            $("#VCHH").show();
           return false;
        } else {
            $("#Vcusto").removeClass("error");
            $("#VCH").hide();
            return true;
        }
    }

    function validalucro() {
        var lu = $("#lucro").val().trim();
        if (lu == "" || lu == "") {
            $("#lucro").addClass("error");
            $("#LuH").show();
           return false;
        } else {
            $("#lucro").removeClass("error");
            $("#LuH").hide();
            return true;
        }


    }


    function validnumR() {
        var numR = $("#numR").val().trim();
        if (numR.length != 3) {
            $("#numR").addClass("error");
            $("#NH").show();
            return false;
        } else {
            $("#numR").removeClass("error");
            $("#NH").hide();
            return true;
        }
    }

    function validacidade() {
        var cidade = $("#cidade").val().trim();
        if (cidade == "") {
            $("#cidade").addClass("error");
            $("#CidH").show();
            return false;
        } else {
            $("#cidade").removeClass("error");
            $("#CidH").hide();
            return true;
        }
    }

    function validabairro() {
        var bairro = $("#bairro").val().trim();
        if (bairro == "") {
            $("#bairro").addClass("error");
            $("#BrH").show();
           return false;
        } else {
            $("#bairro").removeClass("error");
            $("#BrH").hide();
            return true;
        }
    }

    function validarua() {
        var rua = $("#rua").val().trim();
        if (rua == "") {
            $("#rua").addClass("error");
            $("#RH").show();
           return false;
        } else {
            $("#rua").removeClass("error");
            $("#RH").hide();
            return true;
        }
    }

    function validaestado() {
        var estado = $("#estado").val().trim();
        if (estado == "") {
            $("#estado").addClass("error");
            $("#EstH").show();
            return false;
        } else {
            $("#estado").removeClass("error");
            $("#EstH").hide();
            return true;
        }
    }



    $("#validar").click(function () {


       





    });

    $("#enviar").click(function (e) {
        if (validanome() == false) {
            e.preventDefault();
        }
        if (validaemail() == false) {
            e.preventDefault();
        }
        if (validacpf() == false) {
            e.preventDefault();
        }
        if (validaidade() == false) {
            e.preventDefault();
        }
        if (validabairro() == false) {
            e.preventDefault();
        }
        if (validacel() == false) {
            e.preventDefault();
        }
        if (validacidade() == false) {
            e.preventDefault();
        }
        if (validacpf() == false) {
            e.preventDefault();
        }
        if (validaestado() == false) {
            e.preventDefault();
        }
        if (validarua() == false) {
            e.preventDefault();
        }
        if (validacep() == false) {
            e.preventDefault();
        }






        //if (!$("#myForm").submit()) {
        //  return false;
        //}
    });

});