
function showcli(codP) {

    $.get("../Cadastros/BuscaProduto.php?codP=" + codP, function (data, status) {
        if (status == 'success') {
            alert(data);
            var myObjArr = JSON.parse(data);
            $("#nomeP").val(myObjArr[0].descr)
            $("#marca").val(myObjArr[0].marca)
            $("#grupo").val(myObjArr[0].grupo)
            $("#Vvenda").val(myObjArr[0].valorvenda)
            $("#idP").val(myObjArr[0].IDproduto)

        } else {
            alert("Erro na consulta de dados");
        }
    });

   


    /*
        str = nm;
        if (window.XMLHttpRequest) {
            // code for IE7+, Firefox, Chrome, Opera, Safari
            xmlhttp = new XMLHttpRequest();
        } else {
            // code for IE6, IE5
            xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
        }
        xmlhttp.onreadystatechange = function () {
            if (this.readyState == 4 && this.status == 200) {
                myObj = JSON.parse(this.responseText);
                txt = "<table>";
                txt += "<tr><th>Id</th><th>Codigo</th><th>Descriçao</th ><th>Preço Unitario</th><th>Desconto</th><th>Marca</th><th>Grupo</th><th>Operação</th></tr > ";
                for (x in myObj) {
                    txt += "<tr><td>" + myObj[x].codigo + "</td>";
                    txt += "<td>" + myObj[x].nome + "</td>";
                    txt += "<td>" + myObj[x].dtnascto + "</td>";
                    txt += "<td>" + myObj[x].email + "</td>";
                    txt += "<td>" + myObj[x].cpf + "</td>";
                    txt += "<td>" + myObj[x].sexo + "</td>"; txt += "<td> <aref = cli_incalt.php ? id = " + myObj[x].codigo + " & op=A" + " > Editar" + " | "
                        + " < ahref = cli_incalt.php ? id = " + myObj[x].codigo + " & op=D" + " > Excluir" + "</td > ";
                    txt += "</tr>";
                }
                txt += "</table>";
                $.ajax({
                    type: 'GET',
                    url: 'http://localhost/Projeto/Cadastros/BuscaProduto.php',
                    datatype: "json",
                    data: {
                        codigo: $("#codP").val(),
    
                    },
                    success: function (data) {
                        alert(data);
                        if (data == 'ADD_OK') {
                            location.reload();
                        } else {
                            alert('something wrong');
                        }
                    }
                })
    
    
                $('#txtcli').html(txt);
            }*/


}








$(document).ready(function () {
    var i = 0;
    const codigo = [];

    $("#regist").prop('disable', true);
    $("#limpar").prop('disable', true);


    $("#adicionaP").click(function () {


        
        

        codigo.push([$("#idP").val(), $("#quantest").val(),$("#desconto").val()]); 
        console.table(codigo);

        i++;
        alert(codigo + " " + i);




        $("#qtdP").val(i);

    });



    $('#buscaP').click(function () {
        showcli($("#codP").val().trim());
    });


    $("#regist").click(function () {
        $.get("../Cadastros/InsereVenda.php?codigo=" + codigo, function (data, status) {
            if (status == 'success') {
                alert(data);
                
                
    
    
    
            } else {
                alert("Erro na consulta de dados");
            }
    
    
    
    
        });
    


    });

});
