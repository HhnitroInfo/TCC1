$(document).ready(function () {

   

    if ($("#btfisica").isChecked()) {

        $("#cnpj").prop('disabled',true);
        
    } else {
        
    }




});