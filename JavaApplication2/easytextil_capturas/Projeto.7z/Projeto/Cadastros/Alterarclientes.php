<!DOCTYPE html>
<html>

<head>
	<title>Formulário de Teste</title>
	<meta charset="UTF-8">
	<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
	<script src="../Js/ValidaCliente.js"></script>
	<script src="../Js/radiocontrol.js"></script>
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css"
		integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
	<link rel="stylesheet" href="../Css/Main.Css">
</head>

<body>
	<h1>Disciplina : Desenvolvimento Web II</h1>
	<h2>Nome do estudante: Felipe Gai</h2>
	<h2>Professor: Ernani Gottardo</h2>
<?php
require '../PHP/Conexao.php';
	if (isset($_GET['id'])){
$id=$_GET['id']; 
$sql = "SELECT IDcliente,nome,CPF,CNPJ,Email,telefone,datanascimento,sexo,celular,cidade.CEP,cidade.Estado,cidade.cidade,cidade.bairro,cidade.Rua,numero,obs FROM cliente Join cidade on cliente.IDcidade = cidade.IDcidade WHERE IDcliente = $id "  ;
$result=mysqli_query($conn,$sql);
$row = mysqli_fetch_row($result);
$nome = $row[1];
$cpf = $row[2];
$cnpj = $row[3];
$email = $row[4];
$telefone = $row[5];
$datanascimento = $row[6];
$sexo = $row[7];
$celular = $row[8];
$cep = $row[9];
$estado = $row[10];
$cidade = $row[11];
$bairro = $row[12];
$rua = $row[13];
$numero = $row[14];
$obs = $row[15];


	}


?>

	<div id="FormDiv">
		<form id="myForm" method="GET" action="Alterarclientes.php">
		<input type='hidden' name='id' value="<?php echo ($id!=0)?"$id":'0';?>">


			

			<div class="form-group">
				<label for="nome">Nome:</label>
				<input type="text" class="form-control" name="nome" id="nome" value="<?php echo $nome; ?>" aria-describedby="helpId"
					placeholder="Digite o seu Nome Completo">
					<p id= "nomeH" >Digite seu Nome corretamente com pelo menos duas palavras</p>
					
				<label for="email">Email:</label>
				<input type="text" class="form-control" name="email" id="email" value="<?php echo $email; ?>" aria-describedby="helpId"
					placeholder="Digite o seu Email">
					<p id="emailH">Digite seu email corretamente</p>
					
				<label for="cpf">CPF:</label>
				<input type="number" class="form-control" name="cpf" id="cpf" value="<?php echo $cpf; ?>" aria-describedby="helpId"
					placeholder="Digite o seu CPF">
					<p id="CPFH">Digite seu CPF corretamente</p>
					
					<label for="cpf">CNPJ:</label>
				<input type="number" class="form-control" name="cnpj" id="cnpj" value="<?php echo $cnpj; ?>" aria-describedby="helpId"
					placeholder="Digite o seu CNPJ">
					<p id="CNPJH">Digite seu CNPJ corretamente</p>
					
				<label for="">Data de Nascimento:</label>
				<input type="date" class="form-control" name="idade" id="idade" value="<?php echo $datanascimento; ?>" aria-describedby="helpId"
					placeholder="Digite a sua Idade">
					<p id="DTNH">Digite sua Data de nascimento corretamente</p>
					<p id="DTN1H">Voce deve ser maior de 18 anos de idade!</p>
					
				<label for="">Sexo:</label>
				<input type="text" class="form-control" name="Sex" id="sex" value="<?php echo $sexo; ?>" aria-describedby="helpId"
					placeholder="Digite o seu Sexo">
					<p id="SH">Digite seu Sexo corretamente</p>
					
				<label for="">Celular:</label>
				<input type="number" class="form-control" name="cel" id="cel" value="<?php echo $celular; ?>" aria-describedby="helpId"
					placeholder="Digite o seu Numero de Celular">
					<p id="CelH">Digite seu Celular corretamente</p>
					
				<label for="">CEP:</label>
				<input type="numeber" class="form-control" name="cep" id="cep" value="<?php echo $cep; ?>" aria-describedby="helpId"
					placeholder="Digite seu CEP">
					<p id="CEPH">Digite seu CEP corretamente</p>

					
				<label for="">Bairro:</label>
				<input type="text" class="form-control" name="bairro" id="bairro" value="<?php echo $bairro; ?>" aria-describedby="helpId"
					placeholder="Digite o nome da seu Bairro">
					<p id="BrH">Digite seu Bairro corretamente</p>
					
				<label for="">Cidade:</label>
				<input type="text" class="form-control" name="cidade" id="cidade" value="<?php echo $cidade; ?>" aria-describedby="helpId"
					placeholder="Digite o nome da sua Cidade">
					<p id="CidH">Digite sua Cidade corretamente</p>
									
				<label for="">Estado:</label>
				<input type="text" class="form-control" name="estado" id="estado" value="<?php echo $estado; ?>" aria-describedby="helpId"
					placeholder="Digite o nome da seu Estado">
					<p id="EstH">Digite o seu Estado corretamente</p>
					
				<label for="">Rua:</label>
				<input type="text" class="form-control" name="rua" id="rua" value="<?php echo $rua; ?>" aria-describedby="helpId"
					placeholder="Digite o nome da sua Rua">
					<p id="RH">Digite a sua Rua corretamente</p>
					
				<label for="">Numero Residencial:</label>
				<input type="text" class="form-control" name="numR" id="numR" value="<?php echo $numero; ?>" aria-describedby="helpId"
					placeholder="Digite o nome da sua Residencia">
					<p id="NH"> o seu Numero Residencial corretamente</p>

					<label for="">OBS:</label>
				<input type="text" class="form-control" name="obs" id="obs" value="<?php echo $obs; ?>" aria-describedby="helpId"
					placeholder="Digite o nome da sua Residencia">
					<p id="NH"> o a observação corretamente</p>
				
					

				<button type="button" class="btn btn-primary" id="validar">Validar</button>
				<button type="submit" class="btn btn-primary" id="enviar">Enviar</button>
				



		</form>
	</div>
	<p id="errorMessages"></p>


	<script>

	</script>
</body>

</html>



<?php








if (isset($_GET['Enviar'])){

	echo $_GET["nome"];
	$nome = $_GET["nome"];	
	echo $_GET["email"];
	$email = $_GET["email"];	
	echo $_GET["cpf"];
	$CPF = $_GET["cpf"];	
	echo $_GET["cnpj"];
	$CNPJ = $_GET["cnpj"];	
	echo $_GET["cnpj"];
	$CNPJ = $_GET["cnpj"];	
	echo $_GET["idade"];
	$dt = $_GET["idade"];
	$idade = date_create_from_format('Y-m-d', $dt);
	echo " Data Formatada " . date_format($idade, 'd/m/Y');	
	echo $_GET["Sex"];
	$sexo = $_GET["Sex"];	
	echo $_GET["fone"];
	$fone = $_GET["fone"];	
	echo $_GET["cel"];
	$celular = $_GET["cel"];	
	echo $_GET["cep"];
	$CEP = $_GET["cep"];	
	echo $_GET["bairro"];
	$bairro = $_GET["bairro"];	
	echo $_GET["cidade"];
	$Cidade = $_GET["cidade"];	
	echo $_GET["estado"];
	$Estado = $_GET["estado"];	
	echo $_GET["rua"];
	$Rua = $_GET["rua"];	
	echo $_GET["numR"];
	$Numr = $_GET["numR"];	
	echo $_GET["obs"];
	$obs = $_GET["obs"];
$op=$_GET["op"];
//echo "opção ". $op;
if ($id!=0) {
//atualização
if ($op=='A') {
$sql="UPDATE clientes SET nome='$nome', CPF='$cpf',CNPJ='$CNPJ', Email='$email',telefone='$fone',datanascimento =STR_TO_DATE('$data','%Y-%m-%d'),Sexo='$sexo',celular = '$Cel', numero = '$numR', obs ='$OBS' WHERE CODIGO='$id' ";
//$res = mysqli_query($con,$sql);
if (mysqli_query($con,$sql)) {
$_SESSION['msg'] = "<h3>Cliente $nome atualizado com exito!</h3>";
} else {
$_SESSION['msg'] = "<h2>Erro na atualização do cliente $nome " . mysqli_error($con). "</h2>";
//die(mysqli_error($con));
}
mysqli_close($con);
header('Location:Clientes.php'); //carrega o arquivo que foi informado..
} 
//exclusão de clientes
}

/*if (isset($_GET['Excluir'])) {
	$sql="DELETE FROM cliente WHERE IDcilente='$id' ";
if (mysqli_query($con,$sql)) {
$_SESSION['msg'] = "<h3>Cliente $nome excluído com exito!</h3>";
} else {
$_SESSION['msg'] = "<h2>Erro na exclusão do cliente $nome " . mysqli_error($con). "</h2>";
}
mysqli_close($con);
header('Location:Cliente.php');


}*/

$id=0;
}
?>