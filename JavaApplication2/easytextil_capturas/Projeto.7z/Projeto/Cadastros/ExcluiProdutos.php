<?PHP
include "../PHP/Conexao.php";
include "../Cadastros/Produtos.php";
echo $_GET["nomeP"];
$nome = $_GET["nomeP"];
if (isset($_GET['id'])){
    $id=$_GET['id']; 
        }
$sql="DELETE FROM cliente WHERE IDcilente='$id' ";
if (mysqli_query($con,$sql)) {
$_SESSION['msg'] = "<h3>Produto $nome excluído com exito!</h3>";
} else {
$_SESSION['msg'] = "<h2>Erro na exclusão do Produto $nome " . mysqli_error($con). "</h2>";
}
mysqli_close($con);
header('Location:Produtos.php');
?>