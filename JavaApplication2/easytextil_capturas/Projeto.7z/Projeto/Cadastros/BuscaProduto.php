<?php
require '../PHP/conexao.php';
$codigo = $_GET['codP'];

$sql = "SELECT IDproduto,descr,valorvenda,marca,grupo FROM produto WHERE codigo = '$codigo'";



$JSON = array();
$result = mysqli_query($conn, $sql);
while ($r = mysqli_fetch_assoc($result)) {
	$JSON[] = $r;
}
echo json_encode($JSON);
mysqli_close($conn);
?>