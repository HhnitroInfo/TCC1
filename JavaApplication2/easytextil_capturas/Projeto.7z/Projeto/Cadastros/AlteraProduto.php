<!DOCTYPE html>
<html>

<head>
    <title>Formulário de Teste</title>
    <meta charset="UTF-8">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="../Js/"></script>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css"
        integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
    <link rel="stylesheet" href="../Css/Main.Css">
</head>

<body>
    <h1>Disciplina : Desenvolvimento Web II</h1>
    <h2>Nome do estudante: Felipe Gai</h2>
    <h2>Professor: Ernani Gottardo</h2>
    <?php
    if (isset($_GET['id'])) {
        $id = $_GET['id']; 
    }
    ?>


    <div id="FormDiv">
        <form id="myForm" method="GET" action="/Cadastros/CadastroProdutos.php">




            <div class="form-group">
                <label for="nome">Nome:</label>
                <input type="text" class="form-control" name="nomeP" id="nome" aria-describedby="helpId"
                    placeholder="Digite o Nome do produto">
                <p id="nomePH">Digite o Nome do produto corretamente</p>

                <label for="quantest">Qantidade no Estoque:</label>
                <input type="number" class="form-control" name="quantest" id="quantest" aria-describedby="helpId"
                    placeholder="Digite a quantidade em estoque">
                <p id="quantestH">Digite quantos item à em estoque</p>

                <label for="marca">Marca:</label>
                <input type="number" class="form-control" name="marca" id="marca" aria-describedby="helpId"
                    placeholder="Digite a marca do produto">
                <p id="marcaH">Digite a Marca do produto</p>

                <label for="">Grupo:</label>
                <input type="text" class="form-control" name="grupo" id="grupo" aria-describedby="helpId"
                    placeholder="Digite o grupo onde o produto se encontra">
                <p id="grupoH">Digite o grupo onde o produto se encontra</p>

                <label for="">Valor de Custo:</label>
                <input type="number" class="form-control" name="Vcusto" id="Vcusto" aria-describedby="helpId"
                    placeholder="Digite o valor de custo">
                <p id="VCH">Digite o valor de custo</p>

                <label for="">Lucro:</label>
                <input type="number" class="form-control" name="lucro" id="lucro" aria-describedby="helpId"
                    placeholder="Digite o seu Numero de Celular">
                <p id="LuH">Digite o lucro corretamente</p>

                <label for="">Desconto:</label>
                <input type="numeber" class="form-control" name="desconnto" id="desconto" aria-describedby="helpId"
                    placeholder="Digite o desconto do produto">
                <p id="DescH">Digite o desconto do produto corretamente</p>


                <label for="">Valor de Venda:</label>
                <input type="number" class="form-control" name="Vvenda" id="Vvenda" aria-describedby="helpId"
                    placeholder="Digite o Valor de venda do produto">
                <p id="VvenH">Digite o Valor de venda do produto corretamente</p>

                <label for="">Observação:</label>
                <input type="text" class="form-control" name="obs" id="obs" aria-describedby="helpId"
                    placeholder="Digite a boservação do produto">
                <p id="OBSH">Digite a boservação do produto</p>


                <button type="button" class="btn btn-primary" id="validar">Validar</button>
                <button type="submit" class="btn btn-primary" id="enviar">Enviar</button>
               



        </form>
    </div>
    <p id="errorMessages"></p>


    <script>

    </script>
</body>
<?php
session_start();
require '../PHP/Conexao.php';



if (isset($_GET['Enviar'])) {

    $nome = $_GET["nome"];
    $quantest = $_GET["quantest"];
    $marca = $_GET["marca"];
    $grupo = $_GET["grupo"];
    $Vcusto = $_GET["Vcusto"];
    $lucro = $_GET["lucro"];
    $desc = $_GET["desconto"];
    $Vvenda = $_GET["Vvenda"];
    $obs = $_GET["obs"];
    $op = $_GET["op"];
    //echo "opção ". $op;
    if ($id != 0) {
        //atualização
        if ($op == 'A') {
            $sql = "UPDATE clientes SET nome='$nome', quantest=$quantest,marca='$marca',grupo='$grupo', valorcusto='$Vcusto',lucro = '$lucro', desconto = '$desc', valorvenda='$Vvenda', obs='$obs' WHERE IDproduto='$id' ";
            //$res = mysqli_query($con,$sql);
            if (mysqli_query($con, $sql)) {
                $_SESSION['msg'] = "<h3>Cliente $nome atualizado com exito!</h3>";
            } else {
                $_SESSION['msg'] = "<h2>Erro na atualização do cliente $nome " . mysqli_error($con) . "</h2>";
                //die(mysqli_error($con));
            }
            mysqli_close($con);
            header('Location:Clientes.php'); //carrega o arquivo que foi informado..
        }
        //exclusão de clientes

    }
}

/*if (isset($_GET['Excluir'])) {
    $sql = "DELETE FROM produto WHERE IDproduto='$id' ";
    if (mysqli_query($con, $sql)) {
        $_SESSION['msg'] = "<h3>Produto $nome $id excluído com exito!</h3>";
    } else {
        $_SESSION['msg'] = "<h2>Erro na exclusão do Produto $nome $id " . mysqli_error($con) . "</h2>";
    }
    mysqli_close($con);
    header('Location:Produto.php');
}*/


$id = 0;

?>