<?PHP
include "../PHP/Conexao.php";


if (isset($_GET['id'])){
    $id=$_GET['id']; 
        }
$sql="DELETE FROM cliente WHERE IDcliente='$id' ";
echo $sql;
if (mysqli_query($conn,$sql)) {
$_SESSION['msg'] = "<h3>Cliente  excluído com exito!</h3>";
} else {
$_SESSION['msg'] = "<h2>Erro na exclusão do cliente  " . mysqli_error($conn). "</h2>";
}
mysqli_close($conn);
header('Location:Clientes.php');
?>