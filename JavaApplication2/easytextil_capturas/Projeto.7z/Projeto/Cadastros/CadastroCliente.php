<!DOCTYPE html>
<html>

<head>
	<title>Formulário de Teste</title>
	<meta charset="UTF-8">
	<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
	<script src="../Js/ValidaCliente.Js"></script>
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css"
		integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
	<link rel="stylesheet" href="../Css/Main.Css">
</head>

<body>
	<h1>Disciplina : Desenvolvimento Web II</h1>
	<h2>Nome do estudante: Felipe Gai</h2>
	<h2>Professor: Ernani Gottardo</h2>



	<div id="FormDiv">
		<form id="myForm" method="GET" action="IncluirCliente.php">




			<div class="form-group">
				<label for="nome">Nome:</label>
				<input type="text" class="form-control" name="nome" id="nome" aria-describedby="helpId"
					placeholder="Digite o seu Nome Completo">
				<p id="nomeH">Digite o Nome do cliente corretamente com pelo menos duas palavras</p>

				<label for="email">Email:</label>
				<input type="text" class="form-control" name="email" id="email" aria-describedby="helpId"
					placeholder="Digite o seu Email">
				<p id="emailH">Digite seu email corretamente</p>

				<div class="btn-group" data-toggle="buttons">
					<label class="btn btn-primary active">
						<input type="radio" name="" id="" checked autocomplete="off">
					</label>
					<label class="btn btn-primary">
						<input type="radio" name="" id="" autocomplete="off">
					</label>					
				</div>

				<label for="cpf">CPF:</label>
				<input type="number" class="form-control" name="cpf" id="cpf" aria-describedby="helpId"
					placeholder="Digite o seu CPF">
				<p id="CPFH">Digite seu CPF corretamente</p>

				<label for="cpf">CNPJ:</label>
				<input type="number" class="form-control" name="cnpj" id="cnpj" aria-describedby="helpId"
					placeholder="Digite o seu CNPJ">
				<p id="CNPJH">Digite seu CNPJ corretamente</p>

				<label for="">Data de Nascimento:</label>
				<input type="date" class="form-control" name="idade" id="idade" aria-describedby="helpId"
					placeholder="Digite a sua Idade">
				<p id="DTNH">Digite sua Data de nascimento corretamente</p>
				<p id="DTN1H">Voce deve ser maior de 18 anos de idade!</p>

				<label for="">Sexo:</label>
				<input type="text" class="form-control" name="Sex" id="sex" aria-describedby="helpId"
					placeholder="Digite o seu Sexo">
				<p id="SH">Digite seu Sexo corretamente</p>

				<label for="">Celular:</label>
				<input type="number" class="form-control" name="cel" id="cel" aria-describedby="helpId"
					placeholder="Digite o seu Numero de Celular">
				<p id="CelH">Digite seu Celular corretamente</p>

				<label for="">Telefone:</label>
				<input type="number" class="form-control" name="fone" id="fone" aria-describedby="helpId"
					placeholder="Digite o seu Numero de Telefone">
				<p id="FoneH">Digite seu Telefone corretamente</p>

				<label for="">CEP:</label>
				<input type="numeber" class="form-control" name="cep" id="cep" aria-describedby="helpId"
					placeholder="Digite seu CEP">
				<p id="CEPH">Digite seu CEP corretamente</p>


				<label for="">Bairro:</label>
				<input type="text" class="form-control" name="bairro" id="bairro" aria-describedby="helpId"
					placeholder="Digite o nome da seu Bairro">
				<p id="BrH">Digite seu Bairro corretamente</p>

				<label for="">Cidade:</label>
				<input type="text" class="form-control" name="cidade" id="cidade" aria-describedby="helpId"
					placeholder="Digite o nome da sua Cidade">
				<p id="CidH">Digite sua Cidade corretamente</p>

				<label for="">Estado:</label>
				<input type="text" class="form-control" name="estado" id="estado" aria-describedby="helpId"
					placeholder="Digite o nome da seu Estado">
				<p id="EstH">Digite o seu Estado corretamente</p>

				<label for="">Rua:</label>
				<input type="text" class="form-control" name="rua" id="rua" aria-describedby="helpId"
					placeholder="Digite o nome da sua Rua">
				<p id="RH">Digite a sua Rua corretamente</p>

				<label for="">Numero Residencial:</label>
				<input type="text" class="form-control" name="numR" id="numR" aria-describedby="helpId"
					placeholder="Digite o nome da sua Residencia">
				<p id="NH"> o seu Numero Residencial corretamente</p>

				<label for="">Observação do cliente:</label>
				<input type="text" class="form-control" name="obs" id="obs" aria-describedby="helpId"
					placeholder="Digite a observação do cliente">
				<p id="RH">Digite a observação do cliente corretamente</p>


				<button type="button" class="btn btn-primary" id="validar">Validar</button>
				<button type="submit" class="btn btn-primary" id="enviar">Enviar</button>



		</form>
	</div>
	<p id="errorMessages"></p>


	<script>

	</script>
</body>
