<!DOCTYPE html>

<html style="font-size: 16px;" lang="pt"><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    
    <head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta charset="utf-8">
<title>Cadastro de Vendas </title>

<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<link rel="stylesheet"
href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
<meta charset="UTF-8">	
	<script src="../Js/Main.js"></script>	
  <script src="../Js/Busca.js"></script>	
	<link rel="stylesheet" href="../Css/Main.Css">
	<link rel="stylesheet" href="../Css/Other.css">
</head>
<body>
    
<?php
require '../PHP/Conexao.php';
	if (isset($_GET['idC'])){
$idC=$_GET['idC']; 
$sql = "SELECT IDcliente,nome,CPF,CNPJ,Email,telefone,datanascimento,sexo,celular,cidade.CEP,cidade.Estado,cidade.cidade,cidade.bairro,cidade.Rua,numero,obs FROM cliente Join cidade on cliente.IDcidade = cidade.IDcidade WHERE IDcliente = $idC "  ;
$result=mysqli_query($conn,$sql);
$row = mysqli_fetch_row($result);
$nome = $row[1];
$cpf = $row[2];
$cnpj = $row[3];
$email = $row[4];
$telefone = $row[5];
$datanascimento = $row[6];
$sexo = $row[7];
$celular = $row[8];
$cep = $row[9];
$estado = $row[10];
$cidade = $row[11];
$bairro = $row[12];
$rua = $row[13];
$numero = $row[14];
$obs = $row[15];


	}


?>




	<div id="FormDivC">
		<form id="myForm" method="GET" action="">
		<input type='hidden' name='idC' id="idC" value="<?php echo($idC != 0) ? "$idC" : '0'; ?>">


			

			<div class="form-group">
				<label for="nome">Nome:</label>
				<input readonly type="text" class="form-control" name="nome" id="nome" value="<?php echo $nome; ?>" aria-describedby="helpId"
					placeholder="Digite o seu Nome Completo">
					<p id= "nomeH" >Digite seu Nome corretamente com pelo menos duas palavras</p>
					
				<label for="email">Email:</label>
				<input readonly type="text" class="form-control" name="email" id="email" value="<?php echo $email; ?>" aria-describedby="helpId"
					placeholder="Digite o seu Email">
					<p id="emailH">Digite seu email corretamente</p>
					
				<label for="cpf">CPF:</label>
				<input readonly type="number" class="form-control" name="cpf" id="cpf" value="<?php echo $cpf; ?>" aria-describedby="helpId"
					placeholder="Digite o seu CPF">
					<p id="CPFH">Digite seu CPF corretamente</p>
					
					<label for="cpf">CNPJ:</label>
				<input readonly type="number" class="form-control" name="cnpj" id="cnpj" value="<?php echo $cnpj; ?>" aria-describedby="helpId"
					placeholder="Digite o seu CNPJ">
					<p id="CNPJH">Digite seu CNPJ corretamente</p>
					
				 	
			
				<label for="">Celular:</label>
				<input readonly type="number" class="form-control" name="cel" id="cel" value="<?php echo $celular; ?>" aria-describedby="helpId"
					placeholder="Digite o seu Numero de Celular">
					<p id="CelH">Digite seu Celular corretamente</p>
					
				<label for="">CEP:</label>
				<input readonly type="numeber" class="form-control" name="cep" id="cep" value="<?php echo $cep; ?>" aria-describedby="helpId"
					placeholder="Digite seu CEP">
					<p id="CEPH">Digite seu CEP corretamente</p>

					
				<label for="">Bairro:</label>
				<input readonly type="text" class="form-control" name="bairro" id="bairro" value="<?php echo $bairro; ?>" aria-describedby="helpId"
					placeholder="Digite o nome da seu Bairro">
					<p id="BrH">Digite seu Bairro corretamente</p>
					
				<label for="">Cidade:</label>
				<input readonly  type="text" class="form-control" name="cidade" id="cidade" value="<?php echo $cidade; ?>" aria-describedby="helpId"
					placeholder="Digite o nome da sua Cidade">
					<p id="CidH">Digite sua Cidade corretamente</p>
									
				<label for="">Estado:</label>
				<input  readonly type="text" class="form-control" name="estado" id="estado" value="<?php echo $estado; ?>" aria-describedby="helpId"
					placeholder="Digite o nome da seu Estado">
					<p id="EstH">Digite o seu Estado corretamente</p>
					
				<label for="">Rua:</label>
				<input readonly type="text" class="form-control" name="rua" id="rua" value="<?php echo $rua; ?>" aria-describedby="helpId"
					placeholder="Digite o nome da sua Rua">
					<p id="RH">Digite a sua Rua corretamente</p>
					
				<label for="">Numero Residencial:</label>
				<input readonly type="text" class="form-control" name="numR" id="numR" value="<?php echo $numero; ?>" aria-describedby="helpId"
					placeholder="Digite o nome da sua Residencia">
					<p id="NH"> o seu Numero Residencial corretamente</p>

					<label for="">OBS:</label>
				<input readonly type="text" class="form-control" name="obs" id="obs" value="<?php echo $obs; ?>" aria-describedby="helpId"
					placeholder="Digite o nome da sua Residencia">
					<p id="NH"> o a observação corretamente</p>				
		</form>


    
	</div>
  <div id="FormDivP">
        <form id="myForm" method="GET" action="">


		<input type='hidden' name='idP' id="idP" value="">

            <div class="form-group">
                <label for="nome">Codigo do Produto:</label>
                <input type="text" class="form-control" name="codP" id="codP" aria-describedby="helpId"
                    placeholder="Digite o Codigo do produto">
                <p id="nomePH">Digite o Nome do produto corretamente</p>

                <label for="nome">Descrição:</label>
                <input readonly type="text" class="form-control" name="nomeP" id="nomeP" aria-describedby="helpId"
                    placeholder="Digite o Nome do produto">
                <p id="nomePH">Digite o Nome do produto corretamente</p>


                <label for="quantest">Qantidade</label>
                <input type="number" class="form-control" name="quantest" id="quantest" aria-describedby="helpId"
                    placeholder="Digite a quantidade em estoque">
                <p id="quantestH">Digite quantos itens ira comprar</p>

                <label for="marca">Marca:</label>
                <input readonly type="text" class="form-control" name="marca" id="marca" aria-describedby="helpId"
                    placeholder="Digite a marca do produto">
                <p id="marcaH">Digite a Marca do produto</p>

                <label for="">Grupo:</label>
                <input readonly type="text" class="form-control" name="grupo" id="grupo" aria-describedby="helpId"
                    placeholder="Digite o grupo onde o produto se encontra">
                <p id="grupoH">Digite o grupo onde o produto se encontra</p>

                <label for="">Valor do Produto:</label>
                <input readonly type="number" class="form-control" name="Vvenda" id="Vvenda" aria-describedby="helpId"
                    placeholder="Digite o Valor de venda do produto">
                <p id="VvenH">Digite o Valor de venda do produto corretamente</p>

                
                <label for="">Desconto:</label>
                <input type="number" class="form-control" name="desconto" id="desconto" aria-describedby="helpId"
                    placeholder="Digite o desconto do produto">
                <p id="DescH">Digite o desconto do produto corretamente</p>

                <label for="">Valor Total da Venda:</label>
                <input type="number" class="form-control" name="VvendaT" id="VvendaT" aria-describedby="helpId"
                    placeholder="Digite o Valor de venda do produto">
                <p id="VvenH">Digite o Valor de venda do produto corretamente</p>

                

                <button type="button" class="btn btn-primary" id="buscaP">Buscar Produto</button>
				<label for="">Quantidade de produtos</label>
				<input readonly id="qtdP" type="number"> <br>
				<button type="button" class="btn btn-primary" id="adicionaP">Adicionar Produto</button>
                
               



        </form>

		<form id="formenviar" method="GET" action="">
			<button type="submit" id="regist" name="regist" class="btn btn-primary">Registar Venda</button>
			<button type="button" id="limpar" class="btn btn-primary">Limpar formulário Venda</button>
		</form>>
    </div>
    <p id="errorMessages"></p>


  <div>
  

  </div>
	<p id="errorMessages"></p>


	   
    
  
</body>
</html>


<?php
include "../PHP/Conexao.php";




?>