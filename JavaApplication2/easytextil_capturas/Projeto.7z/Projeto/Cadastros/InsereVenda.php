<?php
include "../PHP/Conexao.php";

$codigo = $_GET['codigo'];

var_dump($codigo);

for ($i=0; $i < ; $i++) { 
    
}

?>