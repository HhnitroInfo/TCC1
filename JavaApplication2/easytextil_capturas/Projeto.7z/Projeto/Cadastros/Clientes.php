<?php session_start(); ?>
<html>
<head>
<meta charset="utf-8">
<title>Cadastro de Clientes </title>
<script src='https://kit.fontawesome.com/a076d05399.js'></script>
<!-- Required meta tags -->
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<link rel="stylesheet"
href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
<meta charset="UTF-8">	
		
	<link rel="stylesheet" href="../Css/Main.Css">
	<link rel="stylesheet" href="../Css/table.Css">
</head>
<body>
<h1>Cadastro de Clientes</h1>
<?php
include "../PHP/Conexao.php";
if (isset($_SESSION['msg'])) {
echo $_SESSION['msg'];
unset ($_SESSION['msg']);
}
?>
<h2>
<a href="CadastroCliente.php">Incluir novo cliente</a>
</h2>
<form method="GET" action='Clientes.php'>
<input type='text' name='nome' id='nome' placeholder="digite o nome do cliente"> <br /> <br />
<input type='submit' name='filtrar' value='Filtrar'>
<input type='submit' name='mostrar' value='Mostrar Todos'>
</form>
<br />
<div class="table-reponsive">
<?php
require '../PHP/Conexao.php';
$sql = "SELECT IDcliente,nome,CPF,CNPJ,Email,telefone,datanascimento,sexo,celular,cidade.CEP,cidade.Estado,cidade.cidade,cidade.bairro,cidade.Rua,numero,obs FROM cliente Join cidade on cliente.IDcidade = cidade.IDcidade" ;
//echo "Valor " . $_GET['filtrar'].'<br/>' ;
if (isset($_GET['filtrar'])) {
$nm= $_GET['nome'];
if ($nm!='') {
$sql.=" WHERE UPPER(nome) LIKE UPPER('%$nm%')";
}

unset($_GET['nome']);
unset($_GET['filtrar']);
// echo "Nome após ". $_GET['nome']."<br/>";
}
$sql.=" ORDER BY nome";
$result=mysqli_query($conn,$sql);
//echo $sql;
if (mysqli_affected_rows($conn)>0) {
echo "<table class=table>
<tr>
<th>Id</th>
<th>Nome</th>
<th>CPF</th>
<th>CNPJ</th>
<th>E-mail</th>
<th>Telefone</th>
<th>Data de Nascimento</th>
<th>Sexo</th>
<th>Celular</th>
<th>CEP</th>
<th>Estado</th>
<th>Cidade</th>
<th>Bairro</th>
<th>Rua</th>
<th>Numero Residencial</th>
<th>OBS</th>
<th>Operação</th>
</tr>";
while ($row=mysqli_fetch_row($result))
{
$idade = date_create_from_format('Y-m-d',$row[6] ); //formato padrão data no MySQL
echo "<tr>";
echo "<td>".$row[0]."</td>";
echo "<td>".$row[1]."</td>";
echo "<td>".$row[2]."</td>";
echo "<td>".$row[3]."</td>";
echo "<td>".$row[4]."</td>";
echo "<td>".$row[5]."</td>";
echo "<td>".date_format($idade,'d/m/Y')."</td>";
echo "<td>".$row[7]."</td>";
echo "<td>".$row[8]."</td>";
echo "<td>".$row[9]."</td>";
echo "<td>".$row[10]."</td>";
echo "<td>".$row[11]."</td>";
echo "<td>".$row[12]."</td>";
echo "<td>".$row[13]."</td>";
echo "<td>".$row[14]."</td>";
echo "<td>".$row[15]."</td>";
echo "<td> <a href=AlterarClientes.php?id=".$row[0]."&op=A"."><img src='../IMGs/editicon.png'> ". " | " . "<a href= ExcluiCliente.php?id=".$row[0]. "&op=D". "> <img src='../IMGs/deleticon.jpg'>" . "<a href= CadastroVendas.php?idC=".$row[0]. "&op=D". "> <img src='../IMGs/vendaicon.jpg'>" . "</td>";
} echo "</tr>";
echo "</table>";
}
mysqli_close($conn);
?>
</div>
</body>
</html>
