<?php

include "../PHP/Conexao.php";
/*$sql = "CREATE DATABASE IF NOT EXISTS teste"; if ($conn->query($sql) === TRUE) {
 echo "Database created successfully"; } else {
 echo "Error creating database: " . $conn->error; }
 $conn->close();*/


echo $r = 0;

echo $_GET["nomeP"];
$nome = $_GET["nomeP"];

echo $_GET["nomeP"];
$nome = $_GET["nomeP"];

echo $_GET["quantest"];
$quantest = $_GET["quantest"];

echo $_GET["marca"];
$marca = $_GET["marca"];

echo $_GET["grupo"];
$grupo = $_GET["grupo"];

echo $_GET["valorcusto"];
$vc = $_GET["valorcusto"];

echo $_GET["lucro"];
$lu = $_GET["lucro"];

echo $_GET["desconto"];
$desc = $_GET["descoto"];

echo $_GET["valorvenda"];
$vv = $_GET["valorvenda"];

echo $_GET["obs"];
$obs = $_GET["obs"];


/*$sql = "CREATE TABLE IF NOT EXISTS clientes (
 id INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 Nome VARCHAR(30) NOT NULL,    
 email VARCHAR(50) NOT NULL,
 CPF VARCHAR(50),
 Idade date,
 Sexo VARCHAR(50),
 Celular VARCHAR(50),
 Cep VARCHAR(50),
 Bairro VARCHAR(50),
 Cidade VARCHAR(50),
 Estado VARCHAR(50),
 Rua VARCHAR(50),
 reg_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
 )";*/


$sql = "INSERT INTO produto (nome, quantest,marca,grupo,valorcusto,lucro,desconto,valorvenda,obs )
VALUES ('$nome',$quantest, '$marca','$grupo', $vc, $lu, $desc, $vv ,'$obs')";

if ($conn->query($sql) === TRUE) {
	echo "New record created successfully";
//header('Location:Produto.php');
}
else {
	echo "Error: " . $sql . "<br>" . $conn->error;
	echo "New record created unsuccessfully";
//header('Location:CadastroProduto.php');
}

$conn->close();
?>

</html>