<?php session_start(); ?>
<html>
<head>
<meta charset="utf-8">
<title>Cadastro de Clientes </title>
<script src='https://kit.fontawesome.com/a076d05399.js'></script>
<!-- Required meta tags -->
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<link rel="stylesheet"
href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
<meta charset="UTF-8">	
	<script src="../Js/Main.Js"></script>	
	<link rel="stylesheet" href="../Css/Main.Css">
	<link rel="stylesheet" href="../Css/table.Css">
</head>
<body>
<h1>Cadastro de Produtos</h1>

<?php
include "../PHP/Conexao.php";
if (isset($_SESSION['msg'])) {
echo $_SESSION['msg'];
unset ($_SESSION['msg']);
}
?>
<h2>
<a href="CadastroProdutos.php">Incluir novo Produto</a>
</h2>
<form method="GET" action='Produtos.php'>
<input type='text' name='nome' id='nome' placeholder="digite o nome do Produto"> <br /> <br />
<input type='submit' name='filtrar' value='Filtrar'>
<input type='submit' name='mostrar' value='Mostrar Todos'>
</form>
<br />
<div class="table-reponsive">
<?php
require '../PHP/Conexao.php';
$sql = "SELECT IDproduto,nome,quantest,marca,grupo,valorcusto,lucro,desconto,valorvenda,obs FROM produto" ;
//echo "Valor " . $_GET['filtrar'].'<br/>' ;
if (isset($_GET['filtrar'])) {
$nm= $_GET['nome'];
if ($nm!='') {
$sql.=" WHERE UPPER(nome) LIKE UPPER('%$nm%')";
}

unset($_GET['nome']);
unset($_GET['filtrar']);
// echo "Nome após ". $_GET['nome']."<br/>";
}
$sql.=" ORDER BY nome";
$result=mysqli_query($conn,$sql);
//echo $sql;
if (mysqli_affected_rows($conn)>0) {
echo "<table class=table>
<tr>
<th>Id</th>
<th>Nome</th>
<th>Quamtidade no Estoque</th>
<th>Marca</th>
<th>Grupo</th>
<th>Valor de Custo</th>
<th>Desconto</th>
<th>Desconto</th>
<th>Valor de Venda</th>
<th>OBS</th>
<th>Operação</th>
</tr>";
while ($row=mysqli_fetch_row($result))
{
$idade = date_create_from_format('Y-m-d',$row[4] ); //formato padrão data no MySQL
echo "<tr>";
echo "<td>".$row[0]."</td>";
echo "<td>".$row[1]."</td>";
echo "<td>".$row[2]."</td>";
echo "<td>".$row[3]."</td>";
echo "<td>".$row[4]."</td>";
echo "<td>".$row[6]."</td>";
echo "<td>".$row[6]."</td>";
echo "<td>".$row[7]."</td>";
echo "<td>".$row[8]."</td>";
echo "<td>".$row[9]."</td>";
echo "<td>".$row[10]."</td>";
echo "<td> <a href=AlterarProdutos.php?id=".$row[0]."&op=A"."> <i class='far fa-edit'
title='Alterar'></i>". " | " . "<a href=AlterarProdutos.php?id=".$row[0]. "&op=D". "> <i class='far
fa-trash-alt' title='Alterar'></i>". " | " . "<a href=ExcluiProdutos.php?id=".$row[0]. "&op=D". "</td>";
} echo "</tr>";
echo "</table>";
}
mysqli_close($conn);
?>
</div>
</body>
</html>
