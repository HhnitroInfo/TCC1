<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Formulário de Teste</title>
	<meta charset="UTF-8">
	<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
	<script src="Js/Main.Js"></script>
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css"
		integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
	<link rel="stylesheet" href="Css/Main.Css">
    <title>Document</title>
</head>
<body>

    <h1>Disciplina : Desenvolvimento Web II</h1>
	<h2>Nome do estudante: Felipe Gai</h2>
	<h2>Professor: Ernani Gottardo</h2>

    <button type="button" class="btn btn-primary"><a href="Cadastros/Clientes.php">Cadastro de Clientes</a>     </button>
	<button type="button" class="btn btn-primary"><a href="Cadastros/Produtos.php">Cadastro de Produtos</a>     </button>
	<button type="button" class="btn btn-primary"><a href="Cadastros/.php">Cadastro de Produtos</a>     </button>
    
</body>
</html>