<?php

include "Conexao.php";
/*$sql = "CREATE DATABASE IF NOT EXISTS teste"; if ($conn->query($sql) === TRUE) {
 echo "Database created successfully"; } else {
 echo "Error creating database: " . $conn->error; }
  $conn->close();*/

  echo $r = 0;
 
echo $_GET["nome"];
$nome = $_GET["nome"];

echo $_GET["email"];
$email = $_GET["email"];

echo $_GET["cpf"];
$CPF = $_GET["cpf"];

echo $_GET["cnpj"];
$CNPJ = $_GET["cnpj"];

echo $_GET["cnpj"];
$CNPJ = $_GET["cnpj"];

echo $_GET["idade"];
$dt = $_GET["idade"];
$idade = date_create_from_format('Y-m-d', $dt);
echo " Data Formatada " . date_format($idade, 'd/m/Y');

echo $_GET["Sex"];
$sexo = $_GET["Sex"];

echo $_GET["fone"];
$fone = $_GET["fone"];

echo $_GET["cel"];
$celular = $_GET["cel"];

echo $_GET["cep"];
$CEP = $_GET["cep"];

echo $_GET["bairro"];
$bairro = $_GET["bairro"];

echo $_GET["cidade"];
$Cidade = $_GET["cidade"];

echo $_GET["estado"];
$Estado = $_GET["estado"];

echo $_GET["rua"];
$Rua = $_GET["rua"];

echo $_GET["numR"];
$Numr = $_GET["numR"];

echo $_GET["obs"];
$obs = $_GET["obs"];


/*$sql = "CREATE TABLE IF NOT EXISTS clientes (
 id INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 Nome VARCHAR(30) NOT NULL,    
 email VARCHAR(50) NOT NULL,
 CPF VARCHAR(50),
 Idade date,
 Sexo VARCHAR(50),
 Celular VARCHAR(50),
 Cep VARCHAR(50),
 Bairro VARCHAR(50),
 Cidade VARCHAR(50),
 Estado VARCHAR(50),
 Rua VARCHAR(50),
 reg_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
 )";*/



$sql = "INSERT INTO cidade (CEP,Estado,Rua,bairro,cidade )  
VALUES  ('$CEP','$Estado','$Rua','$bairro','$Cidade' ) ";

require "../PHP/Conexao.php";
/*$sql = "SELECT LAST_INSERT_ID() ";
//$result = mysqli_query($conn,$querry);
mysqli_query($conn, $sql);
$last_id = $conn->insert_id;*/

if ($conn->query($sql) === TRUE) {
    $last_id = $conn->insert_id;
    echo "New record created successfully. Last inserted ID is: " . $last_id;
  } else {
    echo "Error: " . $sql . "<br>" . $conn->error;
  }



$sql = "INSERT INTO cliente (nome,  CPF, CNPJ, Email, telefone, datanascimento, sexo, Celular, IDcidade ,Numero, obs )
VALUES ('$nome','$CPF', '$CNPJ','$email', '$fone', '$dt', '$sexo', '$celular', $last_id ,'$Numr','$obs')";

if ($conn->query($sql) === TRUE) {
    echo "New record created successfully";
}
else {
    echo "Error: ".$sql."<br>".$conn->error;
}

$conn->close();
?>